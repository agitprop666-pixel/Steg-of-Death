from __future__ import annotations

import os
import sys
import struct
import wave
import io
import time
import ctypes
from pathlib import Path

# ── Fix sudo stripping DISPLAY before Qt loads (Linux) ──────────────────────
def _fix_sudo_display():
    if sys.platform.startswith("linux") and not os.environ.get("DISPLAY"):
        os.environ.setdefault("DISPLAY", ":0")
    if sys.platform.startswith("linux"):
        os.environ.setdefault("QT_QPA_PLATFORM", "xcb")

_fix_sudo_display()

# ── PyInstaller-safe resource path ──────────────────────────────────────────
def _resource_path(relative: str) -> Path:
    """Return correct path whether running as script or PyInstaller bundle."""
    base = Path(getattr(sys, "_MEIPASS", Path(__file__).parent))
    return base / relative


# ── PyQt6 ────────────────────────────────────────────────────────────────────
from PyQt6.QtCore import (
    Qt, QSettings, QSize, QThread, pyqtSignal, QTimer
)
from PyQt6.QtGui import (
    QColor, QFont, QIcon, QPainter, QPixmap, QTextCursor, QFontMetrics
)
from PyQt6.QtWidgets import (
    QApplication, QMainWindow, QWidget, QVBoxLayout, QHBoxLayout,
    QLabel, QPushButton, QTextEdit, QLineEdit, QFileDialog,
    QTabWidget, QProgressBar, QSplashScreen, QStatusBar,
    QFrame, QSizePolicy, QComboBox, QCheckBox, QMessageBox,
    QGroupBox, QScrollArea
)

# ── Try Pillow ───────────────────────────────────────────────────────────────
try:
    from PIL import Image
    HAS_PIL = True
except ImportError:
    HAS_PIL = False

# ── Constants ────────────────────────────────────────────────────────────────
APP_NAME    = "Steg of Death"
ORG_NAME    = "Death's Head Software"
APP_VERSION = "1.0.0"
MAGIC       = b"\xDE\xAD\xBE\xEF\xCA\xFE"   # magic marker for binary steg

# ── Dark Theme ───────────────────────────────────────────────────────────────
DARK_STYLE = """
QWidget {
    background-color: #1a1a1a;
    color: #e0e0e0;
    font-family: 'Courier New', Courier, monospace;
    font-size: 12px;
}
QMainWindow, QDialog {
    background-color: #1a1a1a;
}
QTabWidget::pane {
    border: 1px solid #3a3a3a;
    background-color: #1a1a1a;
}
QTabBar::tab {
    background-color: #2a2a2a;
    color: #888;
    padding: 8px 20px;
    border: 1px solid #3a3a3a;
    border-bottom: none;
    font-weight: bold;
    font-size: 12px;
    min-width: 120px;
}
QTabBar::tab:selected {
    background-color: #1a1a1a;
    color: #ffffff;
    border-top: 2px solid #cc0000;
}
QTabBar::tab:hover:!selected {
    background-color: #333;
    color: #ccc;
}
QPushButton {
    background-color: #2a2a2a;
    color: #e0e0e0;
    border: 1px solid #444;
    border-radius: 4px;
    padding: 8px 16px;
    font-weight: bold;
    font-size: 12px;
}
QPushButton:hover {
    background-color: #3a3a3a;
    border-color: #cc0000;
    color: #fff;
}
QPushButton:pressed {
    background-color: #cc0000;
    border-color: #ff0000;
    color: #fff;
}
QPushButton:disabled {
    background-color: #222;
    color: #555;
    border-color: #333;
}
QPushButton#primary_btn {
    background-color: #8b0000;
    border-color: #cc0000;
    color: #ffffff;
    font-size: 13px;
    padding: 10px 24px;
}
QPushButton#primary_btn:hover {
    background-color: #cc0000;
    border-color: #ff2222;
}
QPushButton#primary_btn:pressed {
    background-color: #ff0000;
}
QPushButton#primary_btn:disabled {
    background-color: #3a1a1a;
    color: #666;
    border-color: #4a2a2a;
}
QLineEdit {
    background-color: #111;
    color: #e0e0e0;
    border: 1px solid #444;
    border-radius: 3px;
    padding: 6px 8px;
    selection-background-color: #8b0000;
}
QLineEdit:focus {
    border-color: #cc0000;
}
QTextEdit {
    background-color: #111;
    color: #e0e0e0;
    border: 1px solid #444;
    border-radius: 3px;
    padding: 6px;
    selection-background-color: #8b0000;
}
QTextEdit:focus {
    border-color: #cc0000;
}
QProgressBar {
    background-color: #111;
    border: 1px solid #444;
    border-radius: 3px;
    text-align: center;
    color: #fff;
    height: 18px;
}
QProgressBar::chunk {
    background-color: #8b0000;
    border-radius: 2px;
}
QGroupBox {
    border: 1px solid #3a3a3a;
    border-radius: 4px;
    margin-top: 12px;
    padding-top: 8px;
    color: #aaa;
    font-weight: bold;
}
QGroupBox::title {
    subcontrol-origin: margin;
    left: 10px;
    color: #cc0000;
}
QStatusBar {
    background-color: #111;
    color: #888;
    border-top: 1px solid #333;
    font-size: 11px;
}
QLabel#header_label {
    color: #ffffff;
    font-size: 22px;
    font-weight: bold;
    letter-spacing: 2px;
}
QLabel#sub_label {
    color: #888;
    font-size: 11px;
}
QLabel#info_label {
    color: #cc0000;
    font-size: 11px;
    font-style: italic;
}
QScrollBar:vertical {
    background-color: #111;
    width: 10px;
    border: none;
}
QScrollBar::handle:vertical {
    background-color: #444;
    border-radius: 5px;
    min-height: 20px;
}
QScrollBar::handle:vertical:hover {
    background-color: #8b0000;
}
QScrollBar::add-line:vertical, QScrollBar::sub-line:vertical { height: 0px; }
QScrollBar:horizontal {
    background-color: #111;
    height: 10px;
    border: none;
}
QScrollBar::handle:horizontal {
    background-color: #444;
    border-radius: 5px;
}
QScrollBar::handle:horizontal:hover { background-color: #8b0000; }
QScrollBar::add-line:horizontal, QScrollBar::sub-line:horizontal { width: 0px; }
QComboBox {
    background-color: #111;
    color: #e0e0e0;
    border: 1px solid #444;
    border-radius: 3px;
    padding: 5px 8px;
}
QComboBox:focus { border-color: #cc0000; }
QComboBox::drop-down { border: none; width: 20px; }
QComboBox QAbstractItemView {
    background-color: #1a1a1a;
    color: #e0e0e0;
    border: 1px solid #444;
    selection-background-color: #8b0000;
}
QCheckBox { color: #ccc; spacing: 6px; }
QCheckBox::indicator {
    width: 14px; height: 14px;
    border: 1px solid #555;
    background-color: #111;
    border-radius: 2px;
}
QCheckBox::indicator:checked { background-color: #8b0000; border-color: #cc0000; }
"""

# =============================================================================
# Steganography Engine
# =============================================================================

class StegoEngine:
    """Handles encoding and decoding for multiple file types."""

    DELIMITER = "<<STEG_END>>"

    # ── helpers ──────────────────────────────────────────────────────────────

    @staticmethod
    def _text_to_bits(text: str) -> list[int]:
        data = text.encode("utf-8")
        bits = []
        for byte in data:
            for i in range(7, -1, -1):
                bits.append((byte >> i) & 1)
        return bits

    @staticmethod
    def _bits_to_text(bits: list[int]) -> str:
        chars = []
        for i in range(0, len(bits) - 7, 8):
            byte = 0
            for j in range(8):
                byte = (byte << 1) | bits[i + j]
            chars.append(byte)
        return bytes(chars).decode("utf-8", errors="replace")

    # ── Image LSB ────────────────────────────────────────────────────────────

    @staticmethod
    def _get_pixels(img):
        if hasattr(img, "get_flattened_data"):
            raw = img.get_flattened_data()
            w, h = img.size
            return [(raw[i], raw[i+1], raw[i+2]) for i in range(0, len(raw), 3)]
        return list(img.getdata())  # type: ignore[attr-defined]

    @staticmethod
    def encode_image(carrier_path: str, message: str, output_path: str,
                     progress_cb=None) -> tuple[bool, str]:
        if not HAS_PIL:
            return False, "Pillow not installed. Run: pip install pillow"
        try:
            img = Image.open(carrier_path).convert("RGB")
            pixels = StegoEngine._get_pixels(img)
            full_msg = message + StegoEngine.DELIMITER
            bits = StegoEngine._text_to_bits(full_msg)
            max_bits = len(pixels) * 3
            if len(bits) > max_bits:
                return False, f"Message too large for image ({len(bits)} bits needed, {max_bits} available)"
            new_pixels = []
            bit_idx = 0
            total = len(pixels)
            for i, px in enumerate(pixels):
                r, g, b = px
                if bit_idx < len(bits):
                    r = (r & ~1) | bits[bit_idx]; bit_idx += 1
                if bit_idx < len(bits):
                    g = (g & ~1) | bits[bit_idx]; bit_idx += 1
                if bit_idx < len(bits):
                    b = (b & ~1) | bits[bit_idx]; bit_idx += 1
                new_pixels.append((r, g, b))
                if progress_cb and i % 5000 == 0:
                    progress_cb(int(i / total * 90))
            out = Image.new("RGB", img.size)
            out.putdata(new_pixels)
            # Save losslessly
            ext = Path(output_path).suffix.lower()
            if ext in (".jpg", ".jpeg"):
                output_path = str(Path(output_path).with_suffix(".png"))
            out.save(output_path)
            if progress_cb: progress_cb(100)
            return True, output_path
        except Exception as e:
            return False, str(e)

    @staticmethod
    def decode_image(steg_path: str, progress_cb=None) -> tuple[bool, str]:
        if not HAS_PIL:
            return False, "Pillow not installed. Run: pip install pillow"
        try:
            img = Image.open(steg_path).convert("RGB")
            pixels = StegoEngine._get_pixels(img)
            bits = []
            total = len(pixels)
            for i, px in enumerate(pixels):
                r, g, b = px
                bits.extend([r & 1, g & 1, b & 1])
                if progress_cb and i % 5000 == 0:
                    progress_cb(int(i / total * 90))
                # Early exit check every 8 bits after enough data
                if i > 10 and i % 100 == 0:
                    try:
                        text = StegoEngine._bits_to_text(bits)
                        if StegoEngine.DELIMITER in text:
                            if progress_cb: progress_cb(100)
                            return True, text.split(StegoEngine.DELIMITER)[0]
                    except Exception:
                        pass
            text = StegoEngine._bits_to_text(bits)
            if StegoEngine.DELIMITER in text:
                if progress_cb: progress_cb(100)
                return True, text.split(StegoEngine.DELIMITER)[0]
            return False, "No hidden message found in image."
        except Exception as e:
            return False, str(e)

    # ── Audio WAV LSB ─────────────────────────────────────────────────────────

    @staticmethod
    def encode_audio(carrier_path: str, message: str, output_path: str,
                     progress_cb=None) -> tuple[bool, str]:
        try:
            with wave.open(carrier_path, "rb") as wf:
                params = wf.getparams()
                frames = wf.readframes(wf.getnframes())
                sampwidth = wf.getsampwidth()

            if sampwidth == 1:
                fmt, mask = "B", 0xFF
            elif sampwidth == 2:
                fmt, mask = "<h", 0xFFFF
            else:
                return False, "Unsupported WAV sample width (only 8/16-bit supported)"

            full_msg = message + StegoEngine.DELIMITER
            bits = StegoEngine._text_to_bits(full_msg)
            num_samples = len(frames) // sampwidth
            if len(bits) > num_samples:
                return False, f"Message too large for audio ({len(bits)} bits needed, {num_samples} available)"

            out_frames = bytearray(frames)
            bit_idx = 0
            for i in range(len(bits)):
                offset = i * sampwidth
                sample = struct.unpack_from(fmt, out_frames, offset)[0]
                sample = (sample & ~1) | bits[bit_idx]
                struct.pack_into(fmt, out_frames, offset, sample)
                bit_idx += 1
                if progress_cb and i % 5000 == 0:
                    progress_cb(int(i / len(bits) * 90))

            ext = Path(output_path).suffix.lower()
            if ext != ".wav":
                output_path = str(Path(output_path).with_suffix(".wav"))
            with wave.open(output_path, "wb") as wf:
                wf.setparams(params)
                wf.writeframes(bytes(out_frames))
            if progress_cb: progress_cb(100)
            return True, output_path
        except Exception as e:
            return False, str(e)

    @staticmethod
    def decode_audio(steg_path: str, progress_cb=None) -> tuple[bool, str]:
        try:
            with wave.open(steg_path, "rb") as wf:
                frames = wf.readframes(wf.getnframes())
                sampwidth = wf.getsampwidth()

            if sampwidth == 1:
                fmt = "B"
            elif sampwidth == 2:
                fmt = "<h"
            else:
                return False, "Unsupported WAV sample width"

            num_samples = len(frames) // sampwidth
            bits = []
            total = num_samples
            for i in range(num_samples):
                offset = i * sampwidth
                sample = struct.unpack_from(fmt, frames, offset)[0]
                bits.append(sample & 1)
                if progress_cb and i % 5000 == 0:
                    progress_cb(int(i / total * 90))
                if i > 10 and i % 100 == 0:
                    try:
                        text = StegoEngine._bits_to_text(bits)
                        if StegoEngine.DELIMITER in text:
                            if progress_cb: progress_cb(100)
                            return True, text.split(StegoEngine.DELIMITER)[0]
                    except Exception:
                        pass

            text = StegoEngine._bits_to_text(bits)
            if StegoEngine.DELIMITER in text:
                if progress_cb: progress_cb(100)
                return True, text.split(StegoEngine.DELIMITER)[0]
            return False, "No hidden message found in audio."
        except Exception as e:
            return False, str(e)

    # ── Text / Zero-width ─────────────────────────────────────────────────────

    # Encode bits as zero-width chars: ZWJ=1, ZWNJ=0 between words
    ZWJ  = "\u200d"   # Zero Width Joiner  = 1
    ZWNJ = "\u200c"   # Zero Width Non-Joiner = 0
    ZWSP = "\u200b"   # Zero Width Space = delimiter between bytes

    @staticmethod
    def encode_text(carrier_path: str, message: str, output_path: str,
                    progress_cb=None) -> tuple[bool, str]:
        try:
            with open(carrier_path, "r", encoding="utf-8", errors="replace") as f:
                content = f.read()
            if not content.strip():
                content = "The quick brown fox jumps over the lazy dog."

            full_msg = message + StegoEngine.DELIMITER
            bits = StegoEngine._text_to_bits(full_msg)

            # Build hidden string from zero-width chars
            hidden = ""
            for i, bit in enumerate(bits):
                hidden += StegoEngine.ZWJ if bit else StegoEngine.ZWNJ
            # Inject at start after first char
            result = content[0] + hidden + content[1:]

            with open(output_path, "w", encoding="utf-8") as f:
                f.write(result)
            if progress_cb: progress_cb(100)
            return True, output_path
        except Exception as e:
            return False, str(e)

    @staticmethod
    def decode_text(steg_path: str, progress_cb=None) -> tuple[bool, str]:
        try:
            with open(steg_path, "r", encoding="utf-8", errors="replace") as f:
                content = f.read()

            bits = []
            for ch in content:
                if ch == StegoEngine.ZWJ:
                    bits.append(1)
                elif ch == StegoEngine.ZWNJ:
                    bits.append(0)

            if not bits:
                return False, "No hidden message found in text file."

            text = StegoEngine._bits_to_text(bits)
            if StegoEngine.DELIMITER in text:
                if progress_cb: progress_cb(100)
                return True, text.split(StegoEngine.DELIMITER)[0]
            return False, "No hidden message found in text file."
        except Exception as e:
            return False, str(e)

    # ── Binary / Generic (EOF append) ────────────────────────────────────────

    @staticmethod
    def encode_binary(carrier_path: str, message: str, output_path: str,
                      progress_cb=None) -> tuple[bool, str]:
        try:
            with open(carrier_path, "rb") as f:
                data = f.read()
            payload = message.encode("utf-8")
            length = struct.pack(">I", len(payload))
            out_data = data + MAGIC + length + payload
            with open(output_path, "wb") as f:
                f.write(out_data)
            if progress_cb: progress_cb(100)
            return True, output_path
        except Exception as e:
            return False, str(e)

    @staticmethod
    def decode_binary(steg_path: str, progress_cb=None) -> tuple[bool, str]:
        try:
            with open(steg_path, "rb") as f:
                data = f.read()
            idx = data.rfind(MAGIC)
            if idx == -1:
                return False, "No hidden message found in file."
            idx += len(MAGIC)
            length = struct.unpack(">I", data[idx:idx+4])[0]
            payload = data[idx+4:idx+4+length]
            if progress_cb: progress_cb(100)
            return True, payload.decode("utf-8", errors="replace")
        except Exception as e:
            return False, str(e)

    # ── Router ────────────────────────────────────────────────────────────────

    IMAGE_EXTS = {".png", ".bmp", ".tiff", ".tif", ".gif", ".jpg", ".jpeg", ".webp"}
    AUDIO_EXTS = {".wav"}
    TEXT_EXTS  = {".txt", ".md", ".csv", ".log", ".html", ".xml", ".json", ".py",
                  ".js", ".ts", ".css", ".sh", ".bat", ".ini", ".cfg"}

    @classmethod
    def detect_method(cls, path: str) -> str:
        ext = Path(path).suffix.lower()
        if ext in cls.IMAGE_EXTS: return "image"
        if ext in cls.AUDIO_EXTS: return "audio"
        if ext in cls.TEXT_EXTS:  return "text"
        return "binary"

    @classmethod
    def encode(cls, carrier: str, message: str, output: str,
               progress_cb=None) -> tuple[bool, str]:
        method = cls.detect_method(carrier)
        if method == "image":  return cls.encode_image(carrier, message, output, progress_cb)
        if method == "audio":  return cls.encode_audio(carrier, message, output, progress_cb)
        if method == "text":   return cls.encode_text(carrier, message, output, progress_cb)
        return cls.encode_binary(carrier, message, output, progress_cb)

    @classmethod
    def decode(cls, steg_file: str, progress_cb=None) -> tuple[bool, str]:
        method = cls.detect_method(steg_file)
        if method == "image":  return cls.decode_image(steg_file, progress_cb)
        if method == "audio":  return cls.decode_audio(steg_file, progress_cb)
        if method == "text":   return cls.decode_text(steg_file, progress_cb)
        return cls.decode_binary(steg_file, progress_cb)

    @classmethod
    def capacity_info(cls, carrier: str) -> str:
        """Return a human-readable capacity estimate."""
        try:
            method = cls.detect_method(carrier)
            path = Path(carrier)
            if method == "image" and HAS_PIL:
                img = Image.open(carrier)
                w, h = img.size
                channels = len(img.getbands())
                bits = w * h * min(channels, 3)
                return f"~{bits // 8:,} bytes ({method} LSB)"
            if method == "audio":
                with wave.open(carrier, "rb") as wf:
                    n = wf.getnframes()
                return f"~{n // 8:,} bytes ({method} LSB)"
            if method == "text":
                size = path.stat().st_size
                return f"Unlimited (zero-width injection, carrier {size:,} B)"
            size = path.stat().st_size
            return f"Unlimited (EOF append, carrier {size:,} B)"
        except Exception:
            return "Unknown"


# =============================================================================
# Worker Thread
# =============================================================================

class Worker(QThread):
    progress  = pyqtSignal(int)
    finished  = pyqtSignal(bool, str)

    def __init__(self, mode: str, **kwargs):
        super().__init__()
        self.mode   = mode
        self.kwargs = kwargs

    def run(self):
        try:
            if self.mode == "encode":
                ok, msg = StegoEngine.encode(
                    self.kwargs["carrier"],
                    self.kwargs["message"],
                    self.kwargs["output"],
                    progress_cb=lambda v: self.progress.emit(v)
                )
            else:
                ok, msg = StegoEngine.decode(
                    self.kwargs["steg_file"],
                    progress_cb=lambda v: self.progress.emit(v)
                )
            self.finished.emit(ok, msg)
        except Exception as e:
            self.finished.emit(False, str(e))


# =============================================================================
# File Picker Row
# =============================================================================

class FilePickerRow(QWidget):
    def __init__(self, label: str, placeholder: str, save: bool = False,
                 filter_str: str = "All Files (*)", parent=None):
        super().__init__(parent)
        self._save   = save
        self._filter = filter_str
        layout = QHBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(6)

        self.path_edit = QLineEdit()
        self.path_edit.setPlaceholderText(placeholder)
        layout.addWidget(self.path_edit)

        btn = QPushButton("Browse")
        btn.setFixedWidth(80)
        btn.clicked.connect(self._browse)
        layout.addWidget(btn)

    def _browse(self):
        if self._save:
            path, _ = QFileDialog.getSaveFileName(self, "Save File", "", self._filter)
        else:
            path, _ = QFileDialog.getOpenFileName(self, "Open File", "", self._filter)
        if path:
            self.path_edit.setText(path)

    def get_path(self) -> str:
        return self.path_edit.text().strip()

    def set_path(self, p: str):
        self.path_edit.setText(p)


# =============================================================================
# Encode Tab
# =============================================================================

class EncodeTab(QWidget):
    status_msg = pyqtSignal(str, int)   # message, timeout_ms

    def __init__(self, parent=None):
        super().__init__(parent)
        self._worker = None
        self._build_ui()

    def _build_ui(self):
        root = QVBoxLayout(self)
        root.setContentsMargins(16, 16, 16, 16)
        root.setSpacing(12)

        # ── Carrier ──
        grp_carrier = QGroupBox("Carrier File  (the host)")
        lay_carrier = QVBoxLayout(grp_carrier)
        self.carrier_picker = FilePickerRow(
            "Carrier", "Select file to hide message in…",
            filter_str="All Files (*)"
        )
        self.carrier_picker.path_edit.textChanged.connect(self._on_carrier_changed)
        lay_carrier.addWidget(self.carrier_picker)
        self.capacity_label = QLabel("Capacity: —")
        self.capacity_label.setObjectName("info_label")
        lay_carrier.addWidget(self.capacity_label)
        self.method_label = QLabel("Method: —")
        self.method_label.setObjectName("sub_label")
        lay_carrier.addWidget(self.method_label)
        root.addWidget(grp_carrier)

        # ── Message ──
        grp_msg = QGroupBox("Secret Message")
        lay_msg = QVBoxLayout(grp_msg)
        self.msg_edit = QTextEdit()
        self.msg_edit.setPlaceholderText("Type your secret message here…")
        self.msg_edit.setMinimumHeight(100)
        self.msg_edit.textChanged.connect(self._on_msg_changed)
        lay_msg.addWidget(self.msg_edit)
        self.char_label = QLabel("0 chars / 0 bytes")
        self.char_label.setObjectName("sub_label")
        lay_msg.addWidget(self.char_label)
        root.addWidget(grp_msg)

        # ── Output ──
        grp_out = QGroupBox("Output File")
        lay_out = QVBoxLayout(grp_out)
        self.output_picker = FilePickerRow(
            "Output", "Where to save the steg file…",
            save=True, filter_str="All Files (*)"
        )
        lay_out.addWidget(self.output_picker)
        note = QLabel("ℹ  JPEG carriers will be saved as PNG to preserve LSB data.")
        note.setObjectName("info_label")
        note.setWordWrap(True)
        lay_out.addWidget(note)
        root.addWidget(grp_out)

        # ── Progress ──
        self.progress = QProgressBar()
        self.progress.setValue(0)
        self.progress.setVisible(False)
        root.addWidget(self.progress)

        # ── Button ──
        btn_row = QHBoxLayout()
        btn_row.addStretch()
        self.encode_btn = QPushButton("⚡  ENCODE MESSAGE")
        self.encode_btn.setObjectName("primary_btn")
        self.encode_btn.setMinimumWidth(200)
        self.encode_btn.clicked.connect(self._run_encode)
        btn_row.addWidget(self.encode_btn)
        btn_row.addStretch()
        root.addLayout(btn_row)

        root.addStretch()

    def _on_carrier_changed(self, path: str):
        if not path or not Path(path).exists():
            self.capacity_label.setText("Capacity: —")
            self.method_label.setText("Method: —")
            return
        cap = StegoEngine.capacity_info(path)
        method = StegoEngine.detect_method(path)
        self.capacity_label.setText(f"Capacity: {cap}")
        self.method_label.setText(f"Method: {method.upper()} LSB" if method in ("image","audio") else
                                   f"Method: {'Zero-width Unicode' if method == 'text' else 'EOF binary append'}")
        # Auto-suggest output path
        p = Path(path)
        ext = p.suffix
        if method == "image" and ext.lower() in (".jpg",".jpeg"):
            ext = ".png"
        self.output_picker.set_path(str(p.parent / (p.stem + "_steg" + ext)))

    def _on_msg_changed(self):
        txt = self.msg_edit.toPlainText()
        b = len(txt.encode("utf-8"))
        self.char_label.setText(f"{len(txt):,} chars / {b:,} bytes")

    def _run_encode(self):
        carrier = self.carrier_picker.get_path()
        message = self.msg_edit.toPlainText()
        output  = self.output_picker.get_path()

        if not carrier:
            self.status_msg.emit("⚠  Please select a carrier file.", 4000); return
        if not Path(carrier).exists():
            self.status_msg.emit("⚠  Carrier file not found.", 4000); return
        if not message:
            self.status_msg.emit("⚠  Message is empty.", 4000); return
        if not output:
            self.status_msg.emit("⚠  Please specify an output path.", 4000); return

        self.encode_btn.setEnabled(False)
        self.progress.setValue(0)
        self.progress.setVisible(True)

        self._worker = Worker("encode", carrier=carrier, message=message, output=output)
        self._worker.progress.connect(self.progress.setValue)
        self._worker.finished.connect(self._encode_done)
        self._worker.start()

    def _encode_done(self, ok: bool, msg: str):
        self.progress.setVisible(False)
        self.encode_btn.setEnabled(True)
        if ok:
            self.progress.setValue(100)
            self.status_msg.emit(f"✔  Encoded successfully → {msg}", 8000)
            QMessageBox.information(self, "Success",
                f"Message hidden successfully!\n\nOutput: {msg}")
        else:
            self.status_msg.emit(f"✖  Encode failed: {msg}", 8000)
            QMessageBox.critical(self, "Encode Failed", msg)


# =============================================================================
# Decode Tab
# =============================================================================

class DecodeTab(QWidget):
    status_msg = pyqtSignal(str, int)

    def __init__(self, parent=None):
        super().__init__(parent)
        self._worker = None
        self._build_ui()

    def _build_ui(self):
        root = QVBoxLayout(self)
        root.setContentsMargins(16, 16, 16, 16)
        root.setSpacing(12)

        # ── Input ──
        grp_in = QGroupBox("Steg File  (contains hidden message)")
        lay_in = QVBoxLayout(grp_in)
        self.steg_picker = FilePickerRow(
            "Steg", "Select file that contains a hidden message…",
            filter_str="All Files (*)"
        )
        self.steg_picker.path_edit.textChanged.connect(self._on_steg_changed)
        lay_in.addWidget(self.steg_picker)
        self.method_label = QLabel("Method: —")
        self.method_label.setObjectName("sub_label")
        lay_in.addWidget(self.method_label)
        root.addWidget(grp_in)

        # ── Progress ──
        self.progress = QProgressBar()
        self.progress.setValue(0)
        self.progress.setVisible(False)
        root.addWidget(self.progress)

        # ── Button ──
        btn_row = QHBoxLayout()
        btn_row.addStretch()
        self.decode_btn = QPushButton("🔍  DECODE MESSAGE")
        self.decode_btn.setObjectName("primary_btn")
        self.decode_btn.setMinimumWidth(200)
        self.decode_btn.clicked.connect(self._run_decode)
        btn_row.addWidget(self.decode_btn)
        btn_row.addStretch()
        root.addLayout(btn_row)

        # ── Output ──
        grp_out = QGroupBox("Extracted Message")
        lay_out = QVBoxLayout(grp_out)
        self.result_edit = QTextEdit()
        self.result_edit.setReadOnly(True)
        self.result_edit.setPlaceholderText("Decoded message will appear here…")
        self.result_edit.setMinimumHeight(180)
        lay_out.addWidget(self.result_edit)

        copy_row = QHBoxLayout()
        copy_row.addStretch()
        self.copy_btn = QPushButton("Copy to Clipboard")
        self.copy_btn.setEnabled(False)
        self.copy_btn.clicked.connect(self._copy_result)
        copy_row.addWidget(self.copy_btn)
        self.clear_btn = QPushButton("Clear")
        self.clear_btn.clicked.connect(self._clear_result)
        copy_row.addWidget(self.clear_btn)
        lay_out.addLayout(copy_row)
        root.addWidget(grp_out)

        root.addStretch()

    def _on_steg_changed(self, path: str):
        if not path or not Path(path).exists():
            self.method_label.setText("Method: —"); return
        method = StegoEngine.detect_method(path)
        labels = {
            "image":  "Image LSB (RGB channels)",
            "audio":  "Audio LSB (WAV samples)",
            "text":   "Zero-width Unicode injection",
            "binary": "EOF binary append",
        }
        self.method_label.setText(f"Method: {labels.get(method, method)}")

    def _run_decode(self):
        steg = self.steg_picker.get_path()
        if not steg:
            self.status_msg.emit("⚠  Please select a steg file.", 4000); return
        if not Path(steg).exists():
            self.status_msg.emit("⚠  File not found.", 4000); return

        self.decode_btn.setEnabled(False)
        self.result_edit.clear()
        self.copy_btn.setEnabled(False)
        self.progress.setValue(0)
        self.progress.setVisible(True)

        self._worker = Worker("decode", steg_file=steg)
        self._worker.progress.connect(self.progress.setValue)
        self._worker.finished.connect(self._decode_done)
        self._worker.start()

    def _decode_done(self, ok: bool, msg: str):
        self.progress.setVisible(False)
        self.decode_btn.setEnabled(True)
        if ok:
            self.result_edit.setPlainText(msg)
            self.copy_btn.setEnabled(True)
            self.status_msg.emit(f"✔  Message decoded ({len(msg)} chars)", 6000)
        else:
            self.result_edit.setPlainText("")
            self.status_msg.emit(f"✖  {msg}", 6000)
            QMessageBox.warning(self, "Decode Failed", msg)

    def _copy_result(self):
        QApplication.clipboard().setText(self.result_edit.toPlainText())
        self.status_msg.emit("✔  Copied to clipboard.", 3000)

    def _clear_result(self):
        self.result_edit.clear()
        self.copy_btn.setEnabled(False)


# =============================================================================
# Info Tab
# =============================================================================

class InfoTab(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        layout = QVBoxLayout(self)
        layout.setContentsMargins(16, 16, 16, 16)

        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setFrameShape(QFrame.Shape.NoFrame)
        inner = QWidget()
        inner_layout = QVBoxLayout(inner)
        inner_layout.setSpacing(12)

        def section(title: str, body: str):
            grp = QGroupBox(title)
            lay = QVBoxLayout(grp)
            lbl = QLabel(body)
            lbl.setWordWrap(True)
            lbl.setObjectName("sub_label")
            lbl.setTextFormat(Qt.TextFormat.PlainText)
            lay.addWidget(lbl)
            inner_layout.addWidget(grp)

        section("What is Steganography?",
                "Steganography is the art of hiding information inside other data so that "
                "the very existence of the message is concealed. Unlike encryption, which "
                "makes data unreadable, steganography makes it invisible.")

        section("Supported Methods",
                "IMAGE (PNG, BMP, TIFF, GIF, WEBP)\n"
                "  → LSB (Least Significant Bit) encoding in RGB channels.\n"
                "  → 1 bit per channel = 3 bits per pixel. Visually imperceptible.\n"
                "  → JPEG carriers are auto-converted to PNG (lossless required).\n\n"
                "AUDIO (WAV)\n"
                "  → LSB encoding in raw audio samples (8-bit or 16-bit PCM).\n"
                "  → Inaudible difference in playback.\n\n"
                "TEXT (TXT, MD, HTML, CSV, JSON, code files…)\n"
                "  → Zero-width Unicode characters (U+200C / U+200D) injected\n"
                "    after first character. Invisible in most viewers/editors.\n\n"
                "BINARY (any other file)\n"
                "  → Message appended after EOF with a magic marker.\n"
                "  → File remains fully functional for its original purpose.")

        section("Capacity Guide",
                "A 1920×1080 PNG holds ≈ 777 KB of hidden text.\n"
                "A 44100 Hz, 16-bit, 1-min WAV holds ≈ 330 KB.\n"
                "Text and binary files have essentially unlimited capacity.")

        section("Tips",
                "• Always distribute the OUTPUT file, never the carrier.\n"
                "• Lossless formats (PNG, WAV, BMP) are safest for LSB.\n"
                "• Re-encoding or recompressing a steg image DESTROYS the message.\n"
                "• For maximum deniability, keep message short relative to file size.\n"
                "• Binary append survives most file operations but is detectable\n"
                "  by a hex editor — use image/audio LSB for covert operations.")

        inner_layout.addStretch()
        scroll.setWidget(inner)
        layout.addWidget(scroll)


# =============================================================================
# Main Window
# =============================================================================

class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.settings = QSettings(ORG_NAME, APP_NAME)
        self._build_ui()
        self._restore_geometry()

    def _build_ui(self):
        self.setWindowTitle(f"{APP_NAME}  v{APP_VERSION}")
        self.setMinimumSize(680, 560)

        # ── Icon ──
        self._set_icon()

        # ── Central ──
        central = QWidget()
        self.setCentralWidget(central)
        root = QVBoxLayout(central)
        root.setContentsMargins(0, 0, 0, 0)
        root.setSpacing(0)

        # ── Header ──
        header = QWidget()
        header.setFixedHeight(64)
        header.setStyleSheet("background-color: #111; border-bottom: 1px solid #3a3a3a;")
        hlay = QHBoxLayout(header)
        hlay.setContentsMargins(20, 0, 20, 0)

        skull = QLabel("☠")
        skull.setStyleSheet("font-size: 28px; color: #cc0000;")
        hlay.addWidget(skull)

        title_col = QVBoxLayout()
        title_col.setSpacing(0)
        t1 = QLabel(APP_NAME)
        t1.setObjectName("header_label")
        t2 = QLabel(f"{ORG_NAME}  ·  v{APP_VERSION}")
        t2.setObjectName("sub_label")
        title_col.addWidget(t1)
        title_col.addWidget(t2)
        hlay.addLayout(title_col)
        hlay.addStretch()

        if not HAS_PIL:
            warn = QLabel("⚠  Pillow not installed — image steg disabled")
            warn.setStyleSheet("color: #ff6600; font-size: 11px;")
            hlay.addWidget(warn)

        root.addWidget(header)

        # ── Tabs ──
        self.tabs = QTabWidget()
        self.encode_tab = EncodeTab()
        self.decode_tab = DecodeTab()
        self.info_tab   = InfoTab()
        self.tabs.addTab(self.encode_tab, "⚡  Encode")
        self.tabs.addTab(self.decode_tab, "🔍  Decode")
        self.tabs.addTab(self.info_tab,   "ℹ   About")
        root.addWidget(self.tabs)

        # ── Status bar ──
        self.status = QStatusBar()
        self.setStatusBar(self.status)
        self.status.showMessage("Ready.")

        self.encode_tab.status_msg.connect(self._show_status)
        self.decode_tab.status_msg.connect(self._show_status)

    def _set_icon(self):
        # Windows: tell the taskbar this is its own app (not python.exe)
        if sys.platform == "win32":
            try:
                ctypes.windll.shell32.SetCurrentProcessExplicitAppUserModelID(
                    "DeathsHeadSoftware.StegOfDeath.1"
                )
            except Exception:
                pass
        for name in ("icon.ico", "icon.png"):
            p = _resource_path(name)
            if p.exists():
                self.setWindowIcon(QIcon(str(p)))
                return

    def _show_status(self, msg: str, timeout: int):
        self.status.showMessage(msg, timeout)

    def _restore_geometry(self):
        geom = self.settings.value("geometry")
        if geom:
            self.restoreGeometry(geom)
        else:
            self.resize(800, 640)
            screen = QApplication.primaryScreen().availableGeometry()
            x = (screen.width()  - self.width())  // 2
            y = (screen.height() - self.height()) // 2
            self.move(x, y)

    def closeEvent(self, event):
        self.settings.setValue("geometry", self.saveGeometry())
        super().closeEvent(event)


# =============================================================================
# Splash
# =============================================================================

def create_splash() -> QSplashScreen | None:
    try:
        splash_path = _resource_path("splash.png")
        if splash_path.exists():
            pixmap = QPixmap(str(splash_path))
            if pixmap.isNull():
                pixmap = QPixmap(800, 600)
                pixmap.fill(QColor(20, 20, 20))
            if pixmap.width() != 800 or pixmap.height() != 600:
                pixmap = pixmap.scaled(800, 600,
                                       Qt.AspectRatioMode.KeepAspectRatio,
                                       Qt.TransformationMode.SmoothTransformation)
        else:
            pixmap = QPixmap(800, 600)
            pixmap.fill(QColor(20, 20, 20))

        painter = QPainter(pixmap)
        painter.setPen(QColor(255, 255, 255))

        # Title at top — matches splash_screen.py exactly
        painter.setFont(QFont("Courier", 38, QFont.Weight.Bold))
        text_rect = pixmap.rect()
        text_rect.setTop(40)
        text_rect.setBottom(100)
        painter.drawText(text_rect,
                         Qt.AlignmentFlag.AlignCenter | Qt.AlignmentFlag.AlignVCenter,
                         APP_NAME)

        # Org name at bottom — matches splash_screen.py exactly
        painter.setFont(QFont("Courier", 14, QFont.Weight.Bold))
        footer_rect = pixmap.rect()
        footer_rect.setTop(pixmap.height() - 100)
        footer_rect.setBottom(pixmap.height() - 50)
        painter.drawText(footer_rect,
                         Qt.AlignmentFlag.AlignCenter | Qt.AlignmentFlag.AlignVCenter,
                         ORG_NAME)

        painter.end()
        return QSplashScreen(pixmap, Qt.WindowType.WindowStaysOnTopHint)
    except Exception as e:
        print("Splash error:", e)
        return None


# =============================================================================
# Entry Point
# =============================================================================

def main():
    # High-DPI
    if hasattr(Qt.ApplicationAttribute, "AA_EnableHighDpiScaling"):
        QApplication.setAttribute(Qt.ApplicationAttribute.AA_EnableHighDpiScaling)
    if hasattr(Qt.ApplicationAttribute, "AA_UseHighDpiPixmaps"):
        QApplication.setAttribute(Qt.ApplicationAttribute.AA_UseHighDpiPixmaps)

    app = QApplication(sys.argv)
    app.setApplicationName(APP_NAME)
    app.setOrganizationName(ORG_NAME)
    app.setApplicationVersion(APP_VERSION)
    app.setStyleSheet(DARK_STYLE)

    # Taskbar icon (app-level, before any window opens)
    icon_path = _resource_path("icon.ico")
    if icon_path.exists():
        app.setWindowIcon(QIcon(str(icon_path)))

    splash = create_splash()
    if splash:
        splash.show()
        app.processEvents()

    messages = [
        "Initializing steganography engine…",
        "Loading cryptographic routines…",
        "Preparing pixel manipulation…",
        "Checking audio codecs…",
        "Almost ready…",
    ]

    for msg in messages:
        if splash:
            splash.showMessage(
                "\n\n\n\n\n\n\n\n\n\n" + msg,
                Qt.AlignmentFlag.AlignBottom | Qt.AlignmentFlag.AlignHCenter,
                QColor(200, 200, 200)
            )
            app.processEvents()
        time.sleep(0.35)

    win = MainWindow()
    win.show()

    if splash:
        splash.finish(win)

    sys.exit(app.exec())


if __name__ == "__main__":
    main()
